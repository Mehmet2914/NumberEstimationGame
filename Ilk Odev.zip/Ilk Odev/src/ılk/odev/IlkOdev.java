/*
 Mehmet MUTLU / 20130855031 / Elektrik-Elektronik Mühendisliği (2.Öğretim)
*/

/*
Verilen kavramların açıklanması
a) Nesnel Programlama?
b) JAVA her platform üzerinde nasıl çalışır?
c) SDK,JDK,JVM kavramlarını açıklayınız.
d) Java da nesneleri oluşturulduğu üst sınıfını nedir?
e) try catch nedir?

A)Nesnel programlama kısaca nesne kullanımını destekleyen ve sarmal yapıda 
program yazmaya uyan dilleri tanımlar

B)Java'nin temel felsefesi olan "bir kere yaz, her yerde calistir" sanal makine
sayesinde varolmuştur.Tüm yazılımlar çalışmak için komut kümesine dönüştürülür
sonra işlemci bu komutları gerçek işlemci komutuna dönüştürerek işletir.Sanal
makineninde yaptığı buna benzerdir.Javanın her platformda çalışma sebebi budur.

C)-JVM(Java Virtual Machine):
Java kodlarını çalıştırmayı ve her platformda aynı kodların değiştirilmeden 
kullanılmasını sağlar.
  -JDK(Java Development Kit):
Java geliştiricilerinin uygulamalarını geliştirme olanağı sağlayan, program 
yazma ve çalıştırmayı yerine getiren bir yazılımdır.
JDK;JVM ve JRE’yi bünyesinde bulundurur.
  -SDK(Software Development Kit):
JVM,JRE,JDK ya ek olarak uygulama sunucuları,hata ayıklama araçları,
dökümantasyon vb. yazılımları barındırır.
SDK;JVM ve JRE ve JDK yı barındırır.

D)New operatörü:Bu operator sınıf adı ile birlikte kullanılır ve bellekte sınıfa
ait bir nesne oluşturur. 
Örnek Verirsek;

public class Matematik {
Direnisci Zeytin = new Köpek () {

Zeytin.yas=3;
Zeytin.tur="Labrador";
}
}
-Yukarıdaki örnekte Köpek sınıfına ait zeytin adından bir nesne oluşması için 
yer sağlamış oldu. 

E)Try:Hesaplanmak istenen ifadenin yazıldığı bloktur.
Catch:Try blogunda bir hata tespit edilince hata mesajı veren bloktur  */
package ılk.odev;

import javax.swing.JOptionPane;

public class IlkOdev {
 
    @SuppressWarnings("empty-statement")
    public static void main(String[] args) {
        int tah=0; 
        int sayac=0; 
        boolean dogru = false ; /* mantıksal veri tipi olarak dogru ve yanlısı
     simgeleyen veri tipi  */
      
     String say1 = JOptionPane.showInputDialog(null,"Alt degeri giriniz");
       int alt=Integer.parseInt(say1);
       String say2 =JOptionPane.showInputDialog(null,"Ust degeri giriniz");
       int ust=Integer.parseInt(say2);
  //Ustteki olayda alt ve ust degeri kullanicidan integer olarak almis oluyoruz
       int a = (alt+(int)(Math.random()* ust-alt));
    System.out.println(a); //burda println ifadesini urettigi sayiyi gormeniz icin yaptim hocam
    /*Ust satirdaki kodda bilgisayarin kullanicidan gelen alt ve ust degerler 
       neticesinde bize rastgele integer deger dondurmesini saglamis olduk */
    
      while (!dogru)  //kullanici sayi girene kadar donduruyoruz
      {
      try   //try komutunda yapacagımız işlemleri giriyoruz
      {
      String deger = JOptionPane.showInputDialog("Bir sayi giriniz");
          tah = Integer.parseInt(deger);
          dogru = true ;  
          }
      catch(NumberFormatException e) 
        /*sayi girilmeme hatasını yakalayan catch fonksiyonumuzu kullanıyoruz */
      {
        dogru = false ;  //catch yapısını yanlısı yakalaması icin kullanıyoruz
   JOptionPane.showMessageDialog(null,"Lutfen bir sayi degeri giriniz","Uyarı",JOptionPane.ERROR_MESSAGE);
     // hata mesajını ekrana yazdırıyoruz
      }
      }
      int[] intDizisi;
intDizisi = new int[100]; // 10 luk bir int dizisi oluştur 
        while(a!=tah)// tahmin degeri rastgele sayıya eşit olana kadar donduruyoruz
       {
      if(tah>a)  // tahminin sayidan buyuk olmasını kontrol ediyoruz
     { 
         JOptionPane.showMessageDialog(null,"Daha kucuk tahmin giriniz");
        } 
     if(tah<a)  // tahminin sayidan kucuk olmasını kontrol ediyoruz
     {
         JOptionPane.showMessageDialog(null,"Daha buyuk tahmin giriniz");
       }
    // kullanicidan aldıgımız her yeni sayi degiskenini yeni degiskene atiyoruz
     String deger = JOptionPane.showInputDialog("Bir sayi giriniz");
       tah = Integer.parseInt(deger); //tekrar tahmin degeri alip isleme aktariyoruz
          intDizisi[sayac]=tah; //burda tahmin degerlerini diziye aktariyoruz
       sayac++; // kullanicinin kac kerede tahmin ettigini buluyoruz 
        }  
        JOptionPane.showMessageDialog(null, "Sayiyi bildiniz tebrikler");
        for (int i=0;i<sayac;i++)
        {
            JOptionPane.showMessageDialog(null, "Girdiginiz degerler:" + intDizisi[i] );
    //diziyi ekrana yazdiriyoruz
        }          
       } 
}